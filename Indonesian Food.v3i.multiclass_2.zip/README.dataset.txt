# Indonesian Food > 2024-06-19 12:41pm
https://universe.roboflow.com/sultans-workspace/indonesian-food-urbpq

Provided by a Roboflow user
License: CC BY 4.0

